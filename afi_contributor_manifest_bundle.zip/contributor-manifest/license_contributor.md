# Contributor License (Optional)

By submitting a pull request, you agree that your contributions can be dual-licensed under the AFI public license and any later protocol revisions.

You retain your moral rights and authorship.
