# Onboarding for New Contributors

1. Read the `README.md` in this folder.
2. Choose a working group or area of interest.
3. Fork a relevant repo (start with `afi-labs` if unsure).
4. Join our Discord to get access to early alpha builds and schema previews.
