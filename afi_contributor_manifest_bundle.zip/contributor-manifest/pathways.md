# Contributor Pathways

🚀 Join AFI as a:
- **Validator** – review and score signals
- **Mentor Author** – create cognitive middleware
- **Core Developer** – write and maintain protocol modules
- **Designer/UX** – shape how humans see AFI
- **Agent Builder** – deploy intelligent agents into pipelines

You can participate anonymously or pseudonymously.
