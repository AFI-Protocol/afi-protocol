# Contributor FAQ

**Do I need permission to contribute?**
Nope. Fork, PR, or ask questions in Discord.

**Can I propose new agent types or plugins?**
Yes — submit to the Labs repo or discuss in the #experiments channel.

**How are contributions recognized?**
Via reputation, DAO votes, and protocol mentions.
