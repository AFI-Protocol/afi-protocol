## 🧭 Governance + Contribution

AFI is stewarded by its contributors and anchored by agentic transparency.

- **Contributor Onboarding** → see the [Contributor Manifest](./contributor-manifest/onboarding.md)  
- **Deep-dive Specs & Diagrams** → live in [`afi-docs`](https://github.com/AFI-Protocol/afi-docs) (rendered to GitBook)  
- **Working Groups & Charter** → tracked in this meta-repo as the protocol matures
